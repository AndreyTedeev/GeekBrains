﻿INSERT INTO [dbo].Department VALUES ('Information Technology');
INSERT INTO [dbo].Department VALUES ('Administration');
INSERT INTO [dbo].Employee VALUES ('Andrey','Tedeev', 1);